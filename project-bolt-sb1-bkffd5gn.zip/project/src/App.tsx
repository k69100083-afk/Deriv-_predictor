import React, { useState, useEffect, useRef } from 'react';
import { Activity, Clock, Target, BarChart3, CheckCircle, XCircle } from 'lucide-react';

const DerivPredictor = () => {
  const [prediction, setPrediction] = useState<string | null>(null);
  const [predictedDigit, setPredictedDigit] = useState<number | null>(null);
  const [confidence, setConfidence] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(45);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState('R_75');
  const [lastDigits, setLastDigits] = useState<number[]>([]);
  const [currentPrice, setCurrentPrice] = useState(0);
  const ws = useRef<WebSocket | null>(null);

  const syntheticIndices = [
    { name: 'Volatility 10 Index', symbol: 'R_10' },
    { name: 'Volatility 25 Index', symbol: 'R_25' },
    { name: 'Volatility 50 Index', symbol: 'R_50' },
    { name: 'Volatility 75 Index', symbol: 'R_75' },
    { name: 'Volatility 100 Index', symbol: 'R_100' },
    { name: 'Crash 300 Index', symbol: 'CRASH300' },
    { name: 'Crash 500 Index', symbol: 'CRASH500' },
    { name: 'Boom 300 Index', symbol: 'BOOM300' },
    { name: 'Boom 500 Index', symbol: 'BOOM500' },
    { name: 'Step Index', symbol: 'stpRNG' }
  ];

  useEffect(() => {
    if (ws.current) ws.current.close();

    ws.current = new WebSocket('wss://ws.binaryws.com/websockets/v3?app_id=1089');

    ws.current.onopen = () => {
      ws.current?.send(JSON.stringify({ ticks: selectedIndex }));
    };

    ws.current.onmessage = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.tick) {
        const price = data.tick.quote;
        const lastDigit = Math.floor(Math.abs(price * 100)) % 10;

        setCurrentPrice(price);
        setLastDigits(prev => [...prev.slice(-29), lastDigit]);
      }
    };

    ws.current.onerror = (err) => console.error('WebSocket error:', err);
    ws.current.onclose = () => console.log('WebSocket closed');

    return () => {
      if (ws.current) ws.current.close();
    };
  }, [selectedIndex]);

  const analyzePrediction = () => {
    if (lastDigits.length < 10) {
      alert('Need more tick data... please wait a few more seconds.');
      return;
    }

    setIsAnalyzing(true);

    setTimeout(() => {
      const digitFrequency = Array(10).fill(0);
      lastDigits.forEach(digit => {
        digitFrequency[digit]++;
      });

      const maxFreq = Math.max(...digitFrequency);

      const recentDigits = lastDigits.slice(-5);

      const consecutiveCount = recentDigits.reduce((acc, d, i) => {
        if (i > 0 && d === recentDigits[i - 1]) return acc + 1;
        return acc;
      }, 0);

      const repeatProbability = (consecutiveCount / recentDigits.length) +
                               (maxFreq / lastDigits.length);
      const randomFactor = Math.random();

      const willMatch = repeatProbability > 0.5 ? randomFactor > 0.4 : randomFactor > 0.6;

      let selectedDigit;
      if (willMatch) {
        const lastDigit = recentDigits[recentDigits.length - 1];
        const mostFrequent = digitFrequency.indexOf(maxFreq);
        selectedDigit = Math.random() > 0.5 ? lastDigit : mostFrequent;
      } else {
        selectedDigit = null;
      }

      const predictionType = willMatch ? 'MATCHES' : 'DIFFERS';
      const confidenceScore = Math.round(55 + (Math.abs(repeatProbability - 0.5) * 80));

      setPrediction(predictionType);
      setPredictedDigit(selectedDigit);
      setConfidence(confidenceScore);
      setTimeRemaining(45);
      setIsAnalyzing(false);
    }, 2500);
  };

  useEffect(() => {
    if (prediction && timeRemaining > 0) {
      const timer = setInterval(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (timeRemaining === 0) {
      setPrediction(null);
      setPredictedDigit(null);
    }
  }, [prediction, timeRemaining]);

  const currentLastDigit = Math.floor(Math.abs(currentPrice * 100)) % 10;

  const getPredictionColor = () => {
    return prediction === 'MATCHES' ? 'text-green-500' : 'text-red-500';
  };

  const getPredictionBg = () => {
    return prediction === 'MATCHES'
      ? 'bg-green-500/20 border-green-500'
      : 'bg-red-500/20 border-red-500';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-4xl mx-auto">

        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2 flex items-center justify-center gap-3">
            <Target className="w-10 h-10 text-purple-400" />
            Deriv Matches & Differs AI
          </h1>
          <p className="text-purple-300">Real-Time Last Digit Prediction</p>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 mb-6 border border-slate-700">
          <label className="block text-white mb-3 font-semibold">Select Synthetic Index:</label>
          <select
            value={selectedIndex}
            onChange={(e) => {
              setSelectedIndex(e.target.value);
              setPrediction(null);
              setPredictedDigit(null);
              setLastDigits([]);
            }}
            className="w-full bg-slate-700 text-white px-4 py-3 rounded-lg border border-slate-600 focus:border-purple-500 focus:outline-none"
          >
            {syntheticIndices.map(idx => (
              <option key={idx.symbol} value={idx.symbol}>{idx.name}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm mb-1">Live Price</p>
                <p className="text-2xl font-bold text-white">{currentPrice.toFixed(2)}</p>
              </div>
              <BarChart3 className="w-10 h-10 text-purple-400" />
            </div>
          </div>

          <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm mb-1">Last Digit</p>
                <p className="text-4xl font-bold text-purple-400">{currentLastDigit}</p>
              </div>
              <Target className="w-10 h-10 text-purple-400" />
            </div>
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 mb-6 border border-slate-700">
          <h3 className="text-white font-semibold mb-3">Recent Last Digits History</h3>
          <div className="flex gap-2 flex-wrap">
            {lastDigits.slice(-15).map((digit, idx) => (
              <div
                key={idx}
                className="bg-slate-700 text-white font-bold px-4 py-2 rounded-lg border border-slate-600"
              >
                {digit}
              </div>
            ))}
            {lastDigits.length === 0 && (
              <p className="text-slate-500">Waiting for live tick data...</p>
            )}
          </div>
        </div>

        {prediction ? (
          <div className={`${getPredictionBg()} rounded-xl p-8 mb-6 border-2 backdrop-blur-sm`}>
            <div className="text-center">
              <div className="flex items-center justify-center gap-3 mb-4">
                {prediction === 'MATCHES' ? (
                  <CheckCircle className="w-16 h-16 text-green-500" />
                ) : (
                  <XCircle className="w-16 h-16 text-red-500" />
                )}
                <h2 className={`text-5xl font-bold ${getPredictionColor()}`}>
                  {prediction}
                </h2>
              </div>

              {prediction === 'MATCHES' && predictedDigit !== null && (
                <div className="bg-slate-900/50 rounded-lg p-6 mb-4">
                  <p className="text-slate-400 text-sm mb-2">Predicted Digit</p>
                  <p className="text-6xl font-bold text-green-400">{predictedDigit}</p>
                </div>
              )}

              {prediction === 'DIFFERS' && (
                <div className="bg-slate-900/50 rounded-lg p-4 mb-4">
                  <p className="text-slate-300">Last digit will be <strong>different</strong> from previous</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-slate-900/50 rounded-lg p-4">
                  <p className="text-slate-400 text-sm mb-1">Confidence</p>
                  <p className="text-2xl font-bold text-white">{confidence}%</p>
                </div>
                <div className="bg-slate-900/50 rounded-lg p-4">
                  <p className="text-slate-400 text-sm mb-1 flex items-center justify-center gap-2">
                    <Clock className="w-4 h-4" />
                    Active For
                  </p>
                  <p className="text-2xl font-bold text-white">{timeRemaining}s</p>
                </div>
              </div>

              <div className="w-full bg-slate-900/50 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-1000 ${
                    prediction === 'MATCHES' ? 'bg-green-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${(timeRemaining / 45) * 100}%` }}
                />
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-12 mb-6 border border-slate-700 text-center">
            <Activity className="w-16 h-16 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400 text-lg">No active prediction</p>
            <p className="text-slate-500 text-sm mt-2">
              {lastDigits.length < 10
                ? `Collecting tick data... (${lastDigits.length}/10)`
                : 'Ready to analyze'}
            </p>
          </div>
        )}

        <button
          onClick={analyzePrediction}
          disabled={isAnalyzing || (prediction !== null && timeRemaining > 0) || lastDigits.length < 10}
          className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
            isAnalyzing || (prediction !== null && timeRemaining > 0) || lastDigits.length < 10
              ? 'bg-slate-700 text-slate-500 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700 shadow-lg hover:shadow-xl'
          }`}
        >
          {isAnalyzing ? (
            <span className="flex items-center justify-center gap-2">
              <Activity className="w-5 h-5 animate-spin" />
              Analyzing Last Digit Patterns...
            </span>
          ) : prediction && timeRemaining > 0 ? (
            'Prediction Active - Wait for Timer'
          ) : lastDigits.length < 10 ? (
            `Collecting Live Data... (${lastDigits.length}/10 ticks)`
          ) : (
            'Generate MATCHES/DIFFERS Prediction'
          )}
        </button>

        <div className="mt-6 space-y-4">
          <div className="bg-purple-900/30 backdrop-blur-sm rounded-xl p-4 border border-purple-700">
            <h4 className="text-purple-300 font-semibold mb-2">Live Features:</h4>
            <ul className="text-slate-300 text-sm space-y-1">
              <li>• <strong>Real-time data</strong> from Deriv&apos;s WebSocket API</li>
              <li>• <strong>MATCHES:</strong> Predicts a specific digit that will appear</li>
              <li>• <strong>DIFFERS:</strong> Predicts last digit will be different</li>
              <li>• Predictions stay active for 45+ seconds</li>
            </ul>
          </div>

          <div className="bg-slate-800/30 backdrop-blur-sm rounded-xl p-4 border border-slate-700">
            <p className="text-slate-400 text-sm text-center">
              <strong>Disclaimer:</strong> This uses Deriv&apos;s public WebSocket feed for educational purposes.
              Predictions are for demonstration only — not financial advice. Trading involves significant risk.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DerivPredictor;
